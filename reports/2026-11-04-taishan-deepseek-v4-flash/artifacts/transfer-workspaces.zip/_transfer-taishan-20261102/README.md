# 原始 DeepSeek-V4-Flash → taishan

- 本机源目录：`D:\Models\DeepSeek\DeepSeek-V4-Flash`
- 服务器目标：`taishan:/data/llm/DeepSeek-V4-Flash`
- 来源：已下载并校验的官方 `deepseek-ai/DeepSeek-V4-Flash`，74 个文件，159630045338 字节（约 159.63 GB）。
- 服务器端专用控制目录：`/data/llm/DeepSeek-V4-Flash/.transfer-20261102`

使用本机 SSH 配置中的 `taishan` 别名，Windows 原生 OpenSSH SFTP 传输；不改变父目录 `/data/llm` 的权限，不停止或修改服务器服务。

## 传输与验收

1. 每次最多传输两个文件，写入同目录的 `文件名.transfer.part`。
2. 使用 SFTP `reput` 从已有部分文件继续，不需要从头传输。
3. 每个文件传完，在服务器端按源完整性清单计算 SHA-256；匹配后改为正式文件名，并保存文件级校验记录。
4. 已存在的正式文件必须核验一致才复用；不匹配的正式文件不覆盖。校验失败的临时文件保留为 `.bad-时间戳`。
5. 全部文件通过服务器端校验后，生成 `/data/llm/DeepSeek-V4-Flash/_transfer-verification.json`，并保存来源 `_download-verification.json`。
6. 自动退出。传输完成不等于转换或部署完成，本流程不启动 GGUF 转换或推理服务。

本次已使用 LICENSE 文件实测：先上传前 512 字节，再 `reput` 续传；完整 1084 字节通过服务器端 SHA-256 核验。

## 查看进度

```powershell
$runDir = 'D:\Models\DeepSeek\_transfer-taishan-20261102'
$state = Get-Content -LiteralPath "$runDir\status.json" -Raw | ConvertFrom-Json
$state | Select-Object phase, updated_at, bytes_per_second, error
$state.progress | ConvertTo-Json -Depth 4
Get-Content -LiteralPath "$runDir\transfer.log" -Tail 20
```

- `transfer.pid`：后台传输工作进程 PID。
- `transfer.log`：文件传输、续传与服务器端校验进度。
- `status.json`：当前阶段、每份文件的处理状态、服务器端实际字节数和最近区间速度。
- `stdout.log`、`stderr.log`：工作进程输出。
- `sftp.stdout.log`、`sftp.stderr.log`：原生 SFTP 输出与错误。

进度快照由后台流程每约 10 秒读取一次远端文件大小，不需要聊天会话持续监控。中断后保留原有文件和 `.transfer.part`，确认旧进程退出后可重新运行同一脚本续传。
