import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
import time

ROOT = Path('/data/llm/DeepSeek-V4-Flash').resolve()
CONTROL = ROOT / '.transfer-20261102'
MANIFEST = json.loads((CONTROL / 'source-verification.json').read_text())
FILES = {item['path']: item for item in MANIFEST['files']}
RECORDS = CONTROL / 'verified'

def atomic_json(path, data):
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(data, indent=2))
    os.replace(temporary, path)

def paths(name):
    if name not in FILES:
        raise ValueError('File not in source manifest')
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe relative path')
    final = ROOT.joinpath(*relative.parts)
    if not final.resolve().is_relative_to(ROOT):
        raise ValueError('Path escapes model directory')
    partial = final.with_name(final.name + '.transfer.part')
    return final, partial

def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(8 * 1024 * 1024):
            digest.update(block)
    return digest.hexdigest()

def record_path(name):
    return RECORDS / (hashlib.sha256(name.encode()).hexdigest() + '.json')

def known_good(name, final):
    p = record_path(name)
    if not p.is_file() or not final.is_file():
        return False
    record = json.loads(p.read_text())
    info = final.stat()
    expected = FILES[name]
    return record.get('sha256') == expected['sha256'] and record.get('size') == expected['size'] == info.st_size and record.get('mtime_ns') == info.st_mtime_ns

def record_good(name, final):
    item = FILES[name]
    atomic_json(record_path(name), {'path': name, 'size': item['size'], 'sha256': item['sha256'], 'mtime_ns': final.stat().st_mtime_ns, 'verified_at_unix': time.time()})

def check(name):
    final, partial = paths(name)
    expected = FILES[name]
    if final.exists():
        if not known_good(name, final):
            if final.stat().st_size != expected['size'] or sha256(final) != expected['sha256']:
                raise ValueError(f'Existing destination differs; preserved: {name}')
            record_good(name, final)
        return {'path': name, 'state': 'verified', 'bytes': expected['size']}
    size = partial.stat().st_size if partial.exists() else 0
    if size > expected['size']:
        raise ValueError(f'Oversized partial preserved: {name}')
    return {'path': name, 'state': 'partial' if size else 'missing', 'bytes': size}

def commit(name):
    final, partial = paths(name)
    item = FILES[name]
    if final.exists():
        return check(name)
    if partial.stat().st_size != item['size']:
        raise ValueError(f'Incomplete remote partial: {name}')
    actual = sha256(partial)
    if actual != item['sha256']:
        # Preserve the failed payload and let a retry start a fresh partial.
        bad = partial.with_name(partial.name + f'.bad-{time.time_ns()}')
        partial.rename(bad)
        raise ValueError(f'Remote SHA-256 mismatch; preserved {bad.name}')
    os.replace(partial, final)
    record_good(name, final)
    return {'path': name, 'state': 'verified', 'bytes': item['size']}

def progress():
    complete, transferred, partials = 0, 0, []
    for name, item in FILES.items():
        final, partial = paths(name)
        try:
            if final.is_file() and known_good(name, final):
                complete += 1
                transferred += item['size']
            elif partial.is_file():
                size = partial.stat().st_size
                transferred += size
                partials.append({'path': name, 'bytes': size, 'total': item['size']})
        except FileNotFoundError:
            pass  # A parallel commit just renamed the partial; next snapshot catches it.
    return {'verified_files': complete, 'total_files': len(FILES), 'transferred_bytes': transferred, 'total_bytes': sum(x['size'] for x in FILES.values()), 'partials': partials}

command = sys.argv[1]
if command == 'prepare':
    if not MANIFEST.get('all_files_sha256_verified'):
        raise ValueError('Source manifest was not verified')
    RECORDS.mkdir(exist_ok=True)
    for name in FILES:
        final, _ = paths(name)
        final.parent.mkdir(parents=True, exist_ok=True)
    answer = {'prepared': True, 'files': len(FILES)}
elif command == 'check':
    answer = check(sys.argv[2])
elif command == 'commit':
    answer = commit(sys.argv[2])
elif command == 'progress':
    answer = progress()
elif command == 'finalize':
    for name in FILES:
        if check(name)['state'] != 'verified':
            raise ValueError(f'Missing verified destination: {name}')
    answer = {'model_id': MANIFEST['model_id'], 'completed_at_unix': time.time(), 'all_files_sha256_verified': True, 'files': len(FILES), 'bytes': sum(x['size'] for x in FILES.values()), 'source_manifest_sha256': sha256(CONTROL / 'source-verification.json')}
    atomic_json(ROOT / '_transfer-verification.json', answer)
    (ROOT / '_download-verification.json').write_bytes((CONTROL / 'source-verification.json').read_bytes())
else:
    raise ValueError('Unknown command')
print(json.dumps(answer), flush=True)
