"""Resumable native OpenSSH SFTP transfer, remote SHA-256 before final rename."""
import concurrent.futures
import datetime as dt
import json
import logging
import os
from pathlib import Path, PurePosixPath
import shlex
import subprocess
import sys
import threading
import time

RUN = Path(__file__).resolve().parent
SOURCE = Path(r'D:\Models\DeepSeek\DeepSeek-V4-Flash-W8A8')
REMOTE = '/data/llm/DeepSeek-V4-Flash-W8A8'
HELPER = REMOTE + '/.transfer-20261103-batch3/receiver.py'
OPTIONS = ['-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=30', '-o', 'ServerAliveCountMax=3']
MANIFEST = json.loads((RUN / 'source-verification.json').read_text(encoding='utf-8'))
STOP = threading.Event()
LOCK = threading.RLock()
STATE = {'scope': 'partial_model_batch', 'full_model_files': MANIFEST['full_model_files'], 'phase': 'starting', 'source': str(SOURCE), 'destination': 'taishan:' + REMOTE, 'workers': {}}
CHILD_FLAGS = subprocess.CREATE_NO_WINDOW

def now():
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='seconds')

def save_state(phase=None, **extra):
    with LOCK:
        if phase:
            STATE['phase'] = phase
            logging.info('PHASE %s', phase)
        STATE.update(extra, updated_at=now())
        temporary = RUN / 'status.json.tmp'
        temporary.write_text(json.dumps(STATE, indent=2, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, RUN / 'status.json')

def remote(command, *args, timeout=600):
    text = shlex.join(['python3', HELPER, command, *args])
    result = subprocess.run(['ssh.exe', '-n', *OPTIONS, 'taishan', text], stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=timeout, creationflags=CHILD_FLAGS)
    if result.returncode:
        raise RuntimeError(result.stderr.strip()[-2000:] or result.stdout.strip()[-2000:])
    return json.loads(result.stdout)

def sftp_batch(path):
    with (RUN / 'sftp.stdout.log').open('ab') as stdout, (RUN / 'sftp.stderr.log').open('ab') as stderr:
        process = subprocess.Popen(['sftp.exe', '-b', str(path), *OPTIONS, 'taishan'], stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, creationflags=CHILD_FLAGS)
        started = time.monotonic()
        while process.poll() is None:
            if STOP.wait(1) or time.monotonic() - started > 7200:
                process.terminate()
                process.wait(timeout=15)
                raise RuntimeError('Transfer interrupted; remote partial preserved')
        if process.returncode:
            raise RuntimeError(f'SFTP exit={process.returncode}; see sftp.stderr.log')

def transfer_one(item):
    if STOP.is_set():
        raise concurrent.futures.CancelledError()
    name = item['path']
    local = SOURCE.joinpath(*PurePosixPath(name).parts)
    if local.stat().st_size != item['size']:
        raise ValueError('Local size changed: ' + name)
    batch = RUN / ('batch-' + __import__('hashlib').sha256(name.encode()).hexdigest()[:16] + '.txt')
    target = REMOTE + '/' + name + '.transfer.part'
    for attempt in range(1, 11):
        if STOP.is_set():
            raise concurrent.futures.CancelledError()
        try:
            with LOCK:
                STATE['workers'][name] = {'state': 'checking_destination', 'attempt': attempt}
            save_state()
            check = remote('check', name)
            if check['state'] == 'verified':
                logging.info('VERIFIED existing %s', name)
            else:
                logging.info('UPLOAD %s resume_offset=%s size=%s attempt=%s', name, check['bytes'], item['size'], attempt)
                with LOCK:
                    STATE['workers'][name]['state'] = 'uploading'
                save_state()
                # OpenSSH reput requires an existing remote partial. Use put
                # for a new/empty target, and reput only for positive offsets.
                verb = 'reput' if check['bytes'] > 0 else 'put'
                batch.write_text(f'{verb} "{local.as_posix()}" "{target}"\n', encoding='utf-8')
                sftp_batch(batch)
                with LOCK:
                    STATE['workers'][name]['state'] = 'remote_sha256_verification'
                save_state()
                remote('commit', name)
                logging.info('REMOTE SHA256 VERIFIED %s', name)
            with LOCK:
                STATE['workers'].pop(name, None)
            save_state()
            return
        except Exception as exc:
            if STOP.is_set():
                raise
            logging.warning('RETRY %s attempt=%s error=%s', name, attempt, exc)
            with LOCK:
                STATE['workers'][name].update(state='retry_wait', last_error=str(exc))
            save_state()
            if attempt == 10:
                raise
            if STOP.wait(min(2 ** attempt, 60)):
                raise concurrent.futures.CancelledError()

def monitor():
    previous = None
    while not STOP.is_set():
        try:
            snapshot = remote('progress', timeout=30)
            clock = time.monotonic()
            rate = max(0, (snapshot['transferred_bytes'] - previous[0]) / (clock - previous[1])) if previous else 0
            previous = (snapshot['transferred_bytes'], clock)
            save_state(progress=snapshot, bytes_per_second=round(rate))
            logging.info('PROGRESS %.2f/%.2f GB; %s/%s files SHA256 verified; %.2f MiB/s', snapshot['transferred_bytes'] / 1e9, snapshot['total_bytes'] / 1e9, snapshot['verified_files'], snapshot['total_files'], rate / 1024 ** 2)
        except Exception as exc:
            logging.warning('Progress snapshot unavailable: %s', exc)
        STOP.wait(10)

def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', handlers=[logging.FileHandler(RUN / 'transfer.log', encoding='utf-8'), logging.StreamHandler(sys.stdout)])
    save_state('preparing', started_at=now())
    try:
        remote('prepare')
        save_state('transferring_and_verifying')
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(transfer_one, item) for item in MANIFEST['files']]
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()
                except Exception:
                    STOP.set()
                    for pending in futures:
                        pending.cancel()
                    raise
        STOP.set()
        thread.join(timeout=35)
        save_state('finalizing_remote_verification')
        result = remote('finalize')
        save_state('finalizing_full_model_verification', verification=result)
        full_result = remote('verify_full', timeout=3600)
        save_state('complete_all_remote_sha256_verified', scope='full_model', completed_at=now(), verification=result, full_model_verification=full_result, progress=remote('progress'))
    except Exception as exc:
        STOP.set()
        logging.exception('TRANSFER STOPPED')
        save_state('failed_stopped', error=str(exc))
        raise

if __name__ == '__main__':
    import msvcrt
    with (RUN / 'transfer.lock').open('a+b') as lock:
        if lock.tell() == 0:
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        main()
