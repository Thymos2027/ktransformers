# W8A8 首批传输

源：`D:\Models\DeepSeek\DeepSeek-V4-Flash-W8A8`

目标：`taishan:/data/llm/DeepSeek-V4-Flash-W8A8`

范围：本批 47 个已由下载器校验 SHA-256、与冻结清单一致的文件，共 200,470,758,987 字节。其中 31 个权重分片，其余为当前已就绪的配置和支持文件。仅上传完成文件；不上传 `.part`。

这是部分模型批次。全模型共 65 个文件，仍在本机下载。后续新完成的文件不自动加入本批；下次可建立增量批次。

启动后隐藏运行；2 文件并发，SFTP 支持断点续传，远端 SHA-256 正确才将 `.transfer.part` 重命名为正式文件。不会覆盖不匹配的现存正式文件。

查看 `status.json`、`transfer.log`、`sftp.stderr.log`、`stderr.log`；进程号在 `transfer.pid`。

完成状态：`batch_complete_all_remote_sha256_verified`。远端批次结果位于 `.transfer-20261103-batch1/batch-verification.json`，不代表整个模型已经传输完成。

本批完成后后台进程退出，不持续等待新下载文件，也不启动模型转换或部署。
